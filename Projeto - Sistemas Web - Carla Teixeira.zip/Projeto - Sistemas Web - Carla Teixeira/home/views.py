from django.views.generic import ListView, CreateView, UpdateView, DeleteView, TemplateView
from django.shortcuts import render, get_object_or_404
from django.urls import reverse_lazy
from django.db.models import Sum

from .models import Professor, Disciplina, ProfessorDisciplina, Historico
from .forms import ProfessorForm, DisciplinaForm, HabilitacaoForm, HistoricoForm

class ProfessorListView(ListView):
    model = Professor
    template_name = 'professores/list.html'
    context_object_name = 'professores'

class ProfessorCreateView(CreateView):
    model = Professor
    form_class = ProfessorForm
    template_name = 'professores/form.html'
    success_url = reverse_lazy('lista_professores')

class ProfessorUpdateView(UpdateView):
    model = Professor
    form_class = ProfessorForm
    template_name = 'professores/form.html'
    success_url = reverse_lazy('lista_professores')

class ProfessorDeleteView(DeleteView):
    model = Professor
    template_name = 'professores/confirm_delete.html'
    success_url = reverse_lazy('lista_professores')

class DisciplinaListView(ListView):
    model = Disciplina
    template_name = 'disciplinas/list.html'
    context_object_name = 'disciplinas'

class DisciplinaCreateView(CreateView):
    model = Disciplina
    form_class = DisciplinaForm
    template_name = 'disciplinas/form.html'
    success_url = reverse_lazy('lista_disciplinas')

class DisciplinaUpdateView(UpdateView):
    model = Disciplina
    form_class = DisciplinaForm
    template_name = 'disciplinas/form.html'
    success_url = reverse_lazy('lista_disciplinas')

class DisciplinaDeleteView(DeleteView):
    model = Disciplina
    template_name = 'disciplinas/confirm_delete.html'
    success_url = reverse_lazy('lista_disciplinas')

class ProfessorDisciplinaCreateView(CreateView):
    model = ProfessorDisciplina
    form_class = ProfessorDisciplinaForm
    template_name = 'ProfessorDisciplina/form.html'
    success_url = reverse_lazy('lista_professores')

class HistoricoCreateView(CreateView):
    model = Historico
    form_class = HistoricoForm
    template_name = 'historico/form.html'
    success_url = reverse_lazy('lista_professores')

def consulta_professores_aptos(request):
    disciplinas = Disciplina.objects.all()
    professores = None
    disciplina_escolhida = None

    if request.method == 'POST':
        disciplina_id = request.POST.get('disciplina')
        disciplina_escolhida = get_object_or_404(Disciplina, id=disciplina_id)
        professores = Professor.objects.filter(
            professor_habilitacao__disciplina=disciplina_escolhida
        ).distinct()

    return render(request, 'consultas/aptos.html', {
        'disciplinas': disciplinas,
        'professores': professores,
        'disciplina_escolhida': disciplina_escolhida
    })
def consulta_historico_professor(request):
    professores = Professor.objects.all()
    resultado = []
    professor_escolhido = None

    if request.method == 'POST':
        professor_id = request.POST.get('professor')
        professor_escolhido = get_object_or_404(Professor, id=professor_id)

        resultado = Historico.objects.filter(professor=professor_escolhido) \
            .values('disciplina__nome') \
            .annotate(
                total_carga=Sum('carga_horaria'),
                total_alunos=Sum('quantidade_aluno')
            )

    return render(request, 'consultas/historico.html', {
        'professores': professores,
        'resultado': resultado,
        'professor_escolhido': professor_escolhido
    })





