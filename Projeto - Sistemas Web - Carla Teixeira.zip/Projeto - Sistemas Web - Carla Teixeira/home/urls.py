from django.urls import path
from . import views

urlpatterns = [
    # CRUD de Professores
    path('professores/', views.ProfessorListView.as_view(), name='lista_professores'),
    path('professores/novo/', views.ProfessorCreateView.as_view(), name='criar_professor'),
    path('professores/<int:pk>/editar/', views.ProfessorUpdateView.as_view(), name='editar_professor'),
    path('professores/<int:pk>/excluir/', views.ProfessorDeleteView.as_view(), name='excluir_professor'),

    # CRUD de Disciplinas
    path('disciplinas/', views.DisciplinaListView.as_view(), name='lista_disciplinas'),
    path('disciplinas/novo/', views.DisciplinaCreateView.as_view(), name='criar_disciplina'),
    path('disciplinas/<int:pk>/editar/', views.DisciplinaUpdateView.as_view(), name='editar_disciplina'),
    path('disciplinas/<int:pk>/excluir/', views.DisciplinaDeleteView.as_view(), name='excluir_disciplina'),

    # Associacao professor-disciplina (ProfessorDisciplina)
    path('habilitacoes/nova/', views.HabilitacaoCreateView.as_view(), name='criar_ProfessorDisciplina'),

    # Registro de turmas ministradas
    path('historico/novo/', views.HistoricoCreateView.as_view(), name='criar_historico'),

    # Consultas
    path('consultas/aptos/', views.consulta_professores_aptos, name='consulta_aptos'),
    path('consultas/historico/', views.consulta_historico_professor, name='consulta_historico'),
]
from django.contrib import admin
from django.urls import path

from django.contrib import admin
from django.urls import path, include  

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('home.urls')),  
]


from django.urls import path, include
from rest_framework.routers import DefaultRouter
from home.views import *

urlpatterns = [ 
    path("auth_login/", AuthLogin, name="auth_login"),
    path("logout/", Logout, name="logout"),
    path("base/", Base, name="base"),
    path("", Index, name="index"),

    path("consulta_disciplina/", ConsultaDisciplina, name="consulta_disciplina"),
    path("consulta_professores/", ConsultaProfessores, name="consulta_professores"),
    
    path("professores/", Professores, name="professores"),
    path("professores/<int:id>", Professores, name="professor_id"),
    path("professores/add/", ProfessoresAdd, name="professor_add"),
    path("professores/<int:id>/alter", ProfessoresAlter, name="professor_alter"),



    path("disciplinas/", Disciplinas, name="disciplinas"),
    path("disciplinas/<int:id>", Disciplinas, name="disciplinas_id"),
    path("disciplinas/add/", DisciplinasAdd, name="disciplinas_add"),
    path("disciplinas/<int:id>/alter", DisciplinasAlter, name="disciplinas_alter"),



    path("turmas/", Turmas, name="turmas"),
    path("alunos/", Alunos, name="alunos"),
]