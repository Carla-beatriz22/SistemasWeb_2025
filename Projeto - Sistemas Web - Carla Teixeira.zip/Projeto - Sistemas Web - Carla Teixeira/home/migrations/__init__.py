python manage.py makemigrations home
python manage.py migrate