from django import forms
from .models import Professor, Disciplina, Habilitacao, Historico

class ProfessorForm(forms.ModelForm):
    class Meta:
        model = Professor
        fields = '__all__'

