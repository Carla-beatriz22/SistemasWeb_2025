from .models import Professor, Disciplina, ProfessorDisciplina, TurmaMinistrada

admin.site.register(Professor)
admin.site.register(Disciplina)
admin.site.register(ProfessorDisciplina)
admin.site.register(TurmaMinistrada)
